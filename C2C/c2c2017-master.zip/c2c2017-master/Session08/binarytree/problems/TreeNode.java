class TreeNode {
	TreeNode left;
	TreeNode right;

	final int data;

	public TreeNode(int data) {
		this.data = data;
		this.left = null;
		this.right = null;
	}
}
