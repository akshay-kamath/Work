class Node {
    // TODO
}
