class BubbleSorter implements IntSorter {

    @Override
    public int[] sort(int[] arr) {
        // TODO
        return arr;
    }
}
