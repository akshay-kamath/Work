interface IntSorter {
    int[] sort(int[] arr);
}
