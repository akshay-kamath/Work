# References

This repository really doesn't do justice to these great resources and is in no way an alternative to them. Please do check them out to truly understand the concepts covered in this cheat sheet!

- Computer Science Courses @ Nanyang Technological University, Singapore
- [Cracking the Coding Interview, 6th Edition - Gayle Laakmann McDowell](https://www.amazon.com/Cracking-Coding-Interview-Programming-Questions/dp/0984782850)
- [Hacking a Google Interview Handouts](http://courses.csail.mit.edu/iap/interview/Hacking_a_Google_Interview_Handout_1.pdf)
- [Big O Cheat Sheet](http://bigocheatsheet.com/)
- [GeeksforGeeks](http://www.geeksforgeeks.org/)
- [TutorialsPoint](http://tutorialspoint.com/)
- [schmatz/cs-interview-guide](https://github.com/schmatz/cs-interview-guide)
- [kdn251/Interviews](https://github.com/kdn251/Interviews)
