## TODO

- Data Structures
    - Segment Tree
    - Elaborate Self-Balancing BSTs

- Sorting Algorithms
    - Bucket Sort
    - Radix Sort

- Graph Algorithms
    - Dijkstra's Algorithm / A* Search / Bellman-Ford Algorithm / Floyd-Warshall Algorithm
    - Topological Sorting
    - Minimum Spanning Tree / Prim's Algorithm / Kruskal's Algorithm

- Networking Fundamentals
    - TCP/IP, HTTP, Basics of Search, Firewalls
    - Protocols
    - IP Addresses
