package me.ramswaroop.arrays;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: ramswaroop
 * @date: 5/28/15
 * @time: 12:44 PM
 */
public class LargestProductContiguousSubArray {

    /**
     *
     * @param a
     * @return
     */
    public static int getLargestProductContiguousSubArray(int[] a) {
        return 0;
    }

    public static void main(String a[]) {
        System.out.println(getLargestProductContiguousSubArray(new int[]{-2, 1, -3, 4, 5, -1, 4}));
        System.out.println(getLargestProductContiguousSubArray(new int[]{6, -3, -10, 0, 2}));
    }
}
