package me.ramswaroop.common;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: ramswaroop
 * @date: 4/25/15
 * @time: 10:25 AM
 */
public class AVLTree<E extends Comparable<E>> extends Tree<E> {

}
