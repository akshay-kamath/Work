package me.ramswaroop.common;

/**
 * Created by IntelliJ IDEA.
 * User: ramswaroop
 * Date: 4/19/15
 * Time: 6:30 PM
 * To change this template go to Preferences | IDE Settings | File and Code Templates
 */
public class Tree<E extends Comparable<E>> {

}
