package com.hackerrank.projecteuler;

import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 *
 * @author: ramswaroop
 * @date: 1/1/16
 * @time: 8:48 AM
 */
public class MultiplesOf3and5 {

    public static void main(String a[]) {
        Scanner in = new Scanner(System.in);
        
        int t = Integer.parseInt(in.nextLine());
        
    }
}
